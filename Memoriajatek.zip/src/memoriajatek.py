"""
Memóriajáték

A játékmező alapesetben 4x4-es, és 8 különböző párt tartalmaz, amelyek a következő betűk:
(A, A, B, B, C, C, D, D, E, E, F, F, G, G, H, H).
Ezeket kell megtalálnia a játékosnak.
"""

import random
import os


def display_information():
    """
    Játékleírás
    """
    print("""
    Memóriajáték
    
    A játékmező egy 4x4-es tábla, amely 8 különböző párt (kártyát) tartalmaz.
    A kártyák nagybetűkkel vannak jelölve.
    A cél az összes pár megtalálása.
    Minden körben két kártyát fordíthatsz fel.
    Ha a kártyák megegyeznek, felfedve maradnak.
    Ha nem, visszafordulnak.
    Akkor nyered meg a játékot, ha megtalálod az összes párt.
    """)

def display_statistics(number_of_played_games, pairs_found, all_pairs):
    """
    Játékstatisztika
    """
    # statisztika kiszámítása és megformálása a megjelenítéshez
    reveal_ratio = pairs_found / all_pairs * 100
    number_of_played_games = str(number_of_played_games) + ( (5 - len(str(number_of_played_games))) * ' ')
    pairs_found = str(pairs_found) + ( (8 - len(str(pairs_found))) * ' ')
    all_pairs = str(all_pairs) + ( (13 - len(str(all_pairs))) * ' ')
    reveal_ratio_str = str(reveal_ratio) + '%' + ( (6 - len(str(reveal_ratio))) * ' ')
    print(f"""
    \033[34m######################################\033[0m
    \033[34m##                                  ##\033[0m
    \033[34m##     \033[32mMemóriajáték statisztika\033[0m     \033[34m##\033[0m
    \033[34m##                                  ##\033[0m
    \033[34m##   \033[33mLejátszott játékok száma: {number_of_played_games}\033[34m##\033[0m
    \033[34m##   \033[33mÖsszes pár száma: {all_pairs}\033[34m##\033[0m
    \033[34m##   \033[33mMegtalált párok száma: {pairs_found}\033[34m##\033[0m
    \033[34m##   \033[33mMegtalált párok aránya: {reveal_ratio_str}\033[34m##\033[0m
    \033[34m##                                  ##\033[0m
    \033[34m######################################\033[0m
    """)

def clear_console():
    """
    Törli a konzol tartalmát.
    Windowson 'cls', Linuxon 'clear' parancs segítségével.
    """
    os.system('cls' if os.name == 'nt' else 'clear')

def create_board():
    """
    Létrehoz egy 4x4-es játéktáblát, amely 8 különböző párt tartalmaz.
    A párok nagybetűkkel vannak jelölve.
    :return: A játéktábla
    """
    cards = list('AABBCCDDEEFFGGHH')
    random.shuffle(cards)
    return [cards[i:i+4] for i in range(0, len(cards), 4)]

def display_board(board, revealed, x1=None, y1=None, x2=None, y2=None):
    """
    Kirajzolja a játéktáblát a megadott állapot szerint (mi van felfordítva és mi nincs még).
    :param x1: első pozíció x koodinátája (sor)
    :param y1: első pozíció y koodinátája (oszlop)
    :param x2: második pozíció x koodinátája (sor)
    :param y2: második pozíció y koodinátája (oszlop)
    :param board: a tábla
    :param revealed: melyek a felfordított kártyák
    """
    print()
    print('       ' + ' '.join(str(x+1) for x in range(len(board[0]))))
    print('       ' +  ((2 * len(board[0])) - 1) * '-')
    for i, row in enumerate(board):
        print('    ' + str(i+1), end='| ')
        for j, card in enumerate(row):
            if revealed[i][j]:
                if i == x1 and j == y1 or i == x2 and j == y2:
                    print('\033[33m' + card + '\033[0m', end=' ')
                else:
                    print(card, end=' ')
            else:
                print('*', end=' ')
        print()
    print()

def get_coordinates():
    while True:
        try:
            x, y = map(int, input("Add meg a koordinátákat (sor és oszlop): ").split())
            x -= 1
            y -= 1
            if x in range(4) and y in range(4):
                return x, y
            else:
                print("A koordináták kívül esnek a megengedett tartományon. Próbáld újra.")
        except ValueError:
            print("Érvénytelen bemenet. Két számot adj meg, szóközzel elválasztva.")

def main():
    """
    A játék futtatása:
      - játékmező létrehozása
      - játékstatisztika megjelenítése
      - játékmenet
    """
    clear_console()
    display_information()
    input("Nyomj Entert a folytatáshoz...")

    board = create_board()
    revealed = [[False] * 4 for _ in range(4)]
    pairs_found = 0

    number_of_played_games = 0

    while True:
        while pairs_found < 8:
            clear_console()
            display_statistics(number_of_played_games, pairs_found, 8)
            display_board(board, revealed)
            x1, y1 = get_coordinates()
            x2, y2 = get_coordinates()

            while (x1, y1) == (x2, y2):
                print("Kétszer választottad ugyanazt a kártyát. Próbáld újra.")
                x1, y1 = get_coordinates()
                x2, y2 = get_coordinates()

            if revealed[x1][y1] or revealed[x2][y2]:
                print("Legalább az egyik kártya már fel van fordítva. Próbáld újra.")
                continue

            revealed[x1][y1] = True
            revealed[x2][y2] = True
            clear_console()
            display_board(board, revealed, x1, y1, x2, y2)

            if board[x1][y1] == board[x2][y2]:
                print("Ez egy pár!")
                pairs_found += 1
            else:
                print("Ez sajnos nem talált.")
                revealed[x1][y1] = False
                revealed[x2][y2] = False

            input("Nyomj Entert a folytatáshoz...")

        print("""
        Gratulálok! Megtaláltad az összes párt.
        """)

        if input("Szeretnél új játékot játszani? (i/n): ").lower() == 'i':
            number_of_played_games += 1
            board = create_board()
            revealed = [[False] * 4 for _ in range(4)]
            pairs_found = 0
        else:
            break

if __name__ == "__main__":
    main()